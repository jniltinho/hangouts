#/bin/sh

#Hapus Layar
clear

FOLDER_CONFIG="/srv/v/config_samba4"
FOLDER_SAMBA="/opt/samba4"

ibold="\033[1m"
ebold="\033[0m"
info="[*] INFO: "
echo -e $ibold"########################################################################"
echo -e "# dcpromo.sh version 20121224.005 for OPENSUSE 12.2                    #"
echo -e "# Samba 4 Auto Configuration Script for Active Directory Deployment    #"
echo -e "########################################################################"$ebold

echo ""

#Default Configuration
NAMAFILE="/tmp/dcpromo.ini"


echo -e $ibold"KONFIGURASI DEFAULT"$ebold
echo -n "1. Domain name (FQDN, ex: dominio.local) : "
read NAMADOMAIN
echo -n "2. Hostname               	              : "
read NAMAHOST
echo -n "3. IP Address                            : "
read IPADDRESS
echo -n "4. Gateway/Router                        : "
read GATEWAY
echo -n "5. Admin Password (Strong)               : "
read ADMINPWD


DOM=$(echo $NAMADOMAIN | cut -f 1 -d .) 
NAMADOMAINUPPER=$(echo $NAMADOMAIN | tr '[:lower:]' '[:upper:]')
DOMAIN=$(echo $DOM | tr '[:lower:]' '[:upper:]')

if [ -f $NAMAFILE ]
then
    rm $NAMAFILE
fi
touch $NAMAFILE
echo "NAMADOMAIN=$NAMADOMAIN" >> $NAMAFILE
echo "NAMAHOST=$NAMAHOST" >> $NAMAFILE
echo "IPADDRESS=$IPADDRESS" >> $NAMAFILE
echo "GATEWAY=$GATEWAY" >> $NAMAFILE
echo "ADMINPWD=$ADMINPWD" >> $NAMAFILE
echo "DOMAIN=$DOMAIN" >> $NAMAFILE
echo ""
echo "$info All parameter has been complete, starting configuration process..."
echo ""


echo -e $ibold"STAGE 3 : DNS SERVER AUTO CONFIGURATION, PRESS ENTER TO CONTINUE..."$ebold
read
cd $FOLDER_CONFIG/dns-auto
./dns-auto.sh

cd $FOLDER_CONFIG
 
echo "$info Provisioning samba 4 as Active Directory Server"
echo "$info Command : $FOLDER_SAMBA/bin/samba-tool domain provision --realm=$NAMADOMAIN --domain=$DOMAIN --adminpass='$ADMINPWD' --server-role=dc --dns-backend=BIND9_DLZ"
echo ""
echo "press ENTER to Continue"
read

if [ -f $FOLDER_SAMBA/etc/smb.conf ]
then
    mv $FOLDER_SAMBA/etc/smb.conf $FOLDER_SAMBA/etc/smb.conf.bak
fi

$FOLDER_SAMBA/bin/samba-tool domain provision --realm=$NAMADOMAIN --domain=$DOMAIN --adminpass=$ADMINPWD --server-role=dc --dns-backend=BIND9_DLZ

echo $info"Samba 4 provisioning process as active directory server has been complete"
echo ""
echo "$info Create auto start script into /etc/init.d/samba4"
cp samba4 /etc/init.d/
chmod 755 /etc/init.d/samba4
chmod +x /etc/init.d/samba4
chkconfig samba4 on
service samba4 restart

echo "$info Provisioning Test"
service samba4 status
$FOLDER_SAMBA/sbin/samba --version
#$FOLDER_SAMBA/bin/smbclient -L localhost -U%
#$FOLDER_SAMBA/bin/smbclient //localhost/netlogon -Uadministrator%$ADMINPWD

echo ""
echo -e $ibold"STAGE 5 : DYNAMIC DNS SERVER & KERBEROS CONFIGURATION"$ebold

cp named /etc/sysconfig/named
cp named.conf /etc/named.conf
cp named.conf.smb $FOLDER_SAMBA/private/named.conf
chown -R root:named $FOLDER_SAMBA/private

echo ""
echo "$info Dynamic DNS Server Test"
service named restart
host -t SRV _ldap._tcp.$NAMADOMAIN.
host -t SRV _kerberos._udp.$NAMADOMAIN.
host -t A $NAMADOMAIN.

sed -e "s/EXAMPLE.COM/$NAMADOMAINUPPER/g" -e "s/example.com/$NAMADOMAIN/g" -e "s/kerberos/$NAMAHOST/g" krb5.conf > /tmp/krb5.conf
mv /tmp/krb5.conf /etc/krb5.conf

echo "$info Kerberos Test"
kinit administrator@$NAMADOMAINUPPER
klist -e

echo ""
echo "$info Restarting DNS server service"

service named restart
$FOLDER_SAMBA/sbin/samba_dnsupdate 
#--verbose

echo ""
echo -e $ibold"STAGE 6 : NTP SERVER CONFIGURATION"$ebold
cp ntp.conf /etc/ntp.conf
echo "$info NTP Server configuration and restarting service"

service ntp restart
chkconfig ntp on
service ntp status
ntpq -p

echo ""
echo -e $ibold"STAGE 7 : WINBIND CONFIGURATION"$ebold
ln -s $FOLDER_SAMBA/lib/libnss_winbind.so.2 /lib/libnss_winbind.so
ln -s /lib/libnss_winbind.so /lib/libnss_winbind.so.2
cp nsswitch.conf /etc/nsswitch.conf

echo "$info Winbind Test"
$FOLDER_SAMBA/bin/wbinfo -p
$FOLDER_SAMBA/bin/wbinfo -u
getent passwd
id administrator


