#!/bin/sh

#Hapus Layar
#clear

#echo "########################################################################"
#echo "# DNS-Auto ver 20121004.001 untuk SLES 11 SP2                          #"
#echo "# Skrip untuk otomatisasi konfigurasi DNS Server pada SLES             #"
#echo "# Masim "Vavai" Sugianto - vavai@vavai.com - http://www.vavai.com      #"
#echo "# Artikel 'Active Directory-Samba 4 http://www.excellent.co.id         #"
#echo "########################################################################"

#echo ""

#Default Configuration
startdirectory="/tmp/dns-auto/"
searchterm="vavai.com"
nama_komputer="namahost"
ip_dns="192.168.0.5"
versi=$(grep "VERSION" /etc/SuSE-release | cut -f 2 -d =)

NAMAFILE="/tmp/dcpromo.ini"

#Tanya, punya akses internet tidak ? Jika ya, gunakan repo online
#echo -n "Apakah anda ingin tambah repo online ke http://mirror.linux.or.id? [Y/T] "
#read jawab
jawab="T"
flag_akses_internet="`echo $jawab|tr [a-z] [A-Z]`"

#echo "Tanya nama domain"
#echo ""
#echo "Proses konfigurasi..."
#echo -n "1. Masukkan nama domain (misal : vavai.com) : "
#read nama_domain
#echo -n "2. Masukkan nama komputer (hostname) : "
#read nama_host
#echo ""
#echo -n "3. Masukkan alamat IP (misal : 192.168.0.1) : "
#read alamat_ip
#echo -n "4. Masukkan alamat IP Name Server (Biasanya IP Router/DNS ISP) : "
#read ip_dns_new

nama_domain="`cat $NAMAFILE | grep NAMADOMAIN | cut -f2 -d =`"
nama_host="`cat $NAMAFILE | grep NAMAHOST | cut -f2 -d =`"
alamat_ip="`cat $NAMAFILE | grep IPADDRESS | cut -f2 -d =`"
ip_dns_new="`cat $NAMAFILE | grep GATEWAY | cut -f2 -d =`"


#Reverse IP
subip1=$(echo $alamat_ip | cut -f 1 -d .)
subip2=$(echo $alamat_ip | cut -f 2 -d .)
subip3=$(echo $alamat_ip | cut -f 3 -d .)
subip4=$(echo $alamat_ip | cut -f 4 -d .)

reverse_ip="$subip3.$subip2.$subip1"

echo "Salin file konfigurasi ke folder temporary"
mkdir -p $startdirectory

rsync -a --delete . $startdirectory

#echo "Ubah nama file"

regexp1="s/$searchterm/$nama_domain/2"
find /tmp/dns-auto -name "*$searchterm*" | awk '{print("mv "$1" "$1)}' | sed "$regexp1" | /bin/sh

#echo "Ganti nama reverse DNS"
regexp2="s/0.168.192/$reverse_ip/2"
find /tmp/dns-auto -name "*0.168.192*" | awk '{print("mv "$1" "$1)}' | sed "$regexp2" | /bin/sh

#echo "Ubah konfigurasi $searchterm $startdirectory" 

for file in $(grep -l -R $searchterm $startdirectory)
    do
    sed -e "s/$searchterm/$nama_domain/g" -e "s/192.168.0.1/$alamat_ip/g" -e "s/0.168.192/$reverse_ip/g" -e "s/1.0.168.192/$subip4.$reverse_ip/g" -e "s/1.$reverse_ip/$subip4.$reverse_ip/g" -e "s/$nama_komputer/$nama_host/g" -e "s/$ip_dns/$ip_dns_new/g" $file > /tmp/tempfile.tmp
    mv /tmp/tempfile.tmp $file
#    echo "Modified: " $file
    done
#echo "Done!"
#Ubah Netconfig
cp /etc/sysconfig/network/config /etc/sysconfig/network/config.bak 
cp /etc/sysconfig/network/config /tmp/dns-auto/config.bak
sed -e "s/NETCONFIG_DNS_POLICY='auto'/NETCONFIG_DNS_POLICY=''/g" /tmp/dns-auto/config.bak > /tmp/config.new
mv /tmp/config.new /etc/sysconfig/network/config


#Update konfigurasi
mv /etc/named.conf /etc/named.bak
mv /etc/resolv.conf /etc/resolv.conf.bak
mv /etc/hosts /etc/hosts.bak
mv /etc/named.d/forwarders.conf /etc/named.d/forwarders.conf.bak
if [ -d /var/lib/named/backup-master ]; then
    rm -rf /var/lib/named/backup-master
fi
mv /var/lib/named/master /var/lib/named/backup-master

if [ -d /var/lib/named/master ]; then
  rm -rf /var/lib/named/master
fi
cp /tmp/dns-auto/named/named.conf /etc/named.conf
cp /tmp/dns-auto/named/resolv.conf /etc/resolv.conf
cp /tmp/dns-auto/named/hosts /etc/hosts
cp /tmp/dns-auto/named/forwarders.conf /etc/named.d/forwarders.conf
rsync -a /tmp/dns-auto/named/ /var/lib/named/


#Jalankan service
service named restart

#Test
nslookup "$nama_host.$nama_domain"

echo "Proses konfigurasi DNS secara otomatis telah selesai"
